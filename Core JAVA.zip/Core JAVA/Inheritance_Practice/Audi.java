package Inheritance_Practice;

public class Audi extends car {

	static Audi a=new Audi();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		a.PrintWheel();
		
	}

}
