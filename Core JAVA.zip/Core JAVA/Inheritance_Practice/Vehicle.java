package Inheritance_Practice;

public class Vehicle {

	static Vehicle v=new Vehicle();
	
	int wheel=4;
	public static void main(String[] args) {
		v.PrintWheel();

	}
	public void PrintWheel() {
		// TODO Auto-generated method stub
		System.out.println("In vehicle class\nNo. of wheel is "+wheel);
	}

}
