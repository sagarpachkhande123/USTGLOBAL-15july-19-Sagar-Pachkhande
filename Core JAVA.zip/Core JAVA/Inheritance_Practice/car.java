package Inheritance_Practice;

public class car extends Vehicle {
	static car c=new car();
	String name="Audi";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		c.PrintWheel();
	}
	public void PrintWheel() {
		// TODO Auto-generated method stub
		System.out.println("In Car class\nName of Car is "+name+"\n No. of wheel is "+super.wheel);
	}
}
