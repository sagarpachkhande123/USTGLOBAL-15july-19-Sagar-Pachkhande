package com.dev.encapsulation;

public class DogData {

	
	public static void main(String[] args) {
		Cat d1=new Cat();
		d1.setAge(3);
		
		d1.setColor("Black");
		d1.setName("Shiro");
		
		
		Cat d2=new Cat();
		d2.setAge(3);
		
		d2.setColor("Black");
		d2.setName("Shiro");
		
		Cat d3=new Cat();
		d3.setAge(3);
		
		d3.setColor("Black");
		d3.setName("Shiro");
		
	
		Cat c1=new Cat();
		
		c1.setAge(2);
		c1.setColor("Black");
		c1.setName("Pinky");
		
		Cat c2=new Cat();
		c2.setAge(2);
		c2.setColor("Black");
		c2.setName("Pinky");
		
		
		
//		c1.setAge(3);
//		c1.setColor("Black");
//		c1.setName("Shiro");
		
		
		
		
		
		
		
		Cat [] Cats= {d1,d2,d3};
		Cat [] cats= {c1,c2};
		
		
		for(int i=0;i<Cats.length;i++) {
			
			System.out.println("Name: "+Cats[i].getName());
			
			System.out.println("Age: "+Cats[i].getAge());
			
//			System.out.println("Breed: "+Cats[i].getBreed());
			
			System.out.println("Color: "+Cats[i].getColor());
			
			System.out.println("***************************");
		}
		
		for(Cat i:cats) {
			System.out.println("Name: "+i.getAge());
			System.out.println("Age: "+i.getColor());
			
		}
		System.out.println("\n\n*******Cats*********");
		for(int i=0;i<cats.length;i++) {
			
			System.out.println("Name: "+cats[i].getName());
			
			System.out.println("Age: "+cats[i].getAge());
			
			
			
			System.out.println("Color: "+cats[i].getColor());
			
			System.out.println("***************************");
		}
		
	}
	
}
