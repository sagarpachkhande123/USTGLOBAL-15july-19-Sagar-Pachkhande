package com.dev.encapsulation;

public class StudentData {

	public static void main(String[] args) {
		Student s=new Student();
		
		s.setRegno(2987);
		s.setName("Sagar");
		s.setEmail("sagar@email.com");
		s.setPassword("1234");
		
		
		
		
		
		
		System.out.println("Registration No. is "+s.getRegno());
		
		System.out.println("Name : "+s.getName());
		
		System.out.println("Email : "+s.getEmail());
		
		
	}
}
