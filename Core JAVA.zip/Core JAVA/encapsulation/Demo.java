package com.dev.encapsulation;

public class Demo extends Object {

	public final static int i=10;
	public static void main(String[] args) {
		
	}
}
