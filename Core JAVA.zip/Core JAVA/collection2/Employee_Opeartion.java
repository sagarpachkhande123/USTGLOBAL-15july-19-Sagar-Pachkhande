package com.dev.collection2;

import java.util.HashMap;
import java.util.Iterator;

public class Employee_Opeartion implements Employee_Interface{

	HashMap<Integer, Employee> hm=new HashMap<>();
	
	@Override
	public boolean addEmployee(Employee e) {
		for(int j=1;j<=Main.count;j++) {
			hm.put(j, e);
			return true;
		}	
		return true;
	}
	
	
	@Override
	public boolean removeEmployee(int eid) {
		
		System.out.println("Successfully removed "+hm.remove(eid));
		return true;
	}
	
	
	@Override
	public boolean retreiveEmployee() {
		
		
		
//		Iterator i=hm.entrySet().iterator();
//		while(i.hasNext())
//		{
//			System.out.println(i.next());
//		}			
		return true;
	}

	
}
