package com.dev.collection2;

public class Employee {
	private int Eid;
	private String name;
	private String position;
	public int getEid() {
		return Eid;
	}
	public void setEid(int eid) {
		Eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	@Override
	public String toString() {
		return "Employee [Eid=" + Eid + ", name=" + name + ", position=" + position + "]";
	}
	
	

}
