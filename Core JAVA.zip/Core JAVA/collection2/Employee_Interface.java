package com.dev.collection2;

public interface Employee_Interface {

	 boolean addEmployee(Employee e);
	 boolean removeEmployee(int i);
	 boolean retreiveEmployee();
	
}
