package com.dev.collection2;

import java.util.Scanner;

public class Main {
	public static int count;
	static Employee emp=new Employee();
	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		
		Employee_Opeartion eo=new Employee_Opeartion();
		int n=0;

		while(n<=3)
		{
			System.out.println("****************");
			System.out.println("Enter your Choice\n1. Add Employee\n2. Remove All Employee \n3. Display all EMployeees\n");
			System.out.println("****************");
			n=sc.nextInt();

			switch(n)
			{
			case 1:

				System.out.println("How Many Employess you want to Add");
				int no=sc.nextInt();
				for(int i=1;i<=no;i++) {

					System.out.println("****Enter Employee Details "+i+"****");

					System.out.println("Enter Employee Id in integer format");
					int eid=sc.nextInt();
					
					System.out.println("Enter Employee Name");
					String name=sc.next();

					System.out.println("Enter Employee Position");
					String position=sc.next();

					emp.setEid(eid);
					emp.setName(name);
					emp.setPosition(position);

					
					if(eo.addEmployee(emp))
					{
						System.out.println("Employee are Successfully added");
					}
					count++;
				}

				break;
			case 2:

				System.out.println("Enter key to delete from Employee");
				int eid_remove=sc.nextInt();

				eo.removeEmployee(eid_remove);

				break;
			case 3:

				eo.retreiveEmployee();

				break;


			}


			//			System.out.println(eo.retreiveEmployee());


		}
	}
}
