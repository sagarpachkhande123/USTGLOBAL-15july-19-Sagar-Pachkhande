package com.dev.multi_threading_Practice;

public class SyncMain {

	
	
	public static void main(String[] args) {
		Printer p=new Printer();
		
		
		System.out.println("Main Method Started");
		
		Thread1 t1=new Thread1(p);
		t1.start();
		
		
	}
}
