package com.dev.multi_threading_Practice;

public class Thread2 extends Thread {
	
	

}
