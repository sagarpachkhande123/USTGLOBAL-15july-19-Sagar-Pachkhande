package com.dev.multi_threading_Practice;

public class Thread1 extends Thread {

	Printer p;
	
	public Thread1(Printer p) {
		this.p=p;
	}
	
	@Override
	public void run() {		
			p.printVal(10,"Thread");
		}
}
