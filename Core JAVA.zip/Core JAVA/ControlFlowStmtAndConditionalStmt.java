
import java.util.*;
class ControlFlowStmtAndConditionalStmt{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);

		String nm;
		System.out.println("Enter Number\n");
		int n=sc.nextInt();
		System.out.println("Enter Name\n");
		nm=sc.next();
		int i;
		if(n<=5 && n>0)
		{
				
				System.out.println("Hello "+nm+"..");
				switch(n)
				{
					case 1:
							System.out.println("Day is Monday");
							break;
					case 2:
							System.out.println("Day is Tuesday");
							break;
					case 3:
							System.out.println("Day is Wednesday");
							break;
					case 4:
							System.out.println("Day is Thursday");
							break;
					case 5:
							System.out.println("Day is Friday");
							break;
					
				}

		}
		if(n>5 && n<=7)
		{
			switch(n)
				{
					case 6:
							System.out.println("Day is Saturday..Its Weekend");
					case 7:
							System.out.println("Day is Sunday..Its Weekend");
				}
		
			for(i=0;i<=4;i++)
			{

				System.out.println("Hello "+nm+"..");
				
			}
		}
		
	}
}