package com.dev.Abstraction;

public class Implement_Interface implements ABS_Interface{

	@Override
	public void display() {
		// TODO Auto-generated method stub
	
	}
	

}
