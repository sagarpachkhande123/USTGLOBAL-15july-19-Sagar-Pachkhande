package com.dev.Abstraction;

public class Print_Class extends Abstract_Superclass  {
	@Override
	public void print() {
		// TODO Auto-generated method stub
		
		System.out.println("Print method of Print_Class");
		
	}

	@Override
	void display() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void sagar() {
		// TODO Auto-generated method stub
		
	}
	
}
