package com.dev.Abstraction;


public interface Interface3 extends Interface2 {
	void display();
	void show();
	static void print() {
		System.out.println("");
	}
	

}
