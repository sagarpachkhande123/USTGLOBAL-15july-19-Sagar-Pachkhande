package com.dev.Abstraction;

@FunctionalInterface
public interface ABS_Interface {
	
	void display();
	
	
	
	static int i=9;
	
	
	
	public static void sagar() {
		
	}

}

interface ABS{
	
}
