package com.dev.Abstraction;

public interface Interface2 extends ABS_Interface{

}
