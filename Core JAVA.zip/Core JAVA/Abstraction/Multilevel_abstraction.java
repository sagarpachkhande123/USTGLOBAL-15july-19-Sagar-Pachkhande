package com.dev.Abstraction;
import com.dev.Abstraction.*;
public class Multilevel_abstraction extends  Abstract_Subclass1{
	
	static Multilevel_abstraction Ma=new Multilevel_abstraction();
	static Print_Class pc=new Print_Class();
	
	public static void main(String[] args) {
		Ma.display();
		Ma.show();
		Ma.sagar();
		pc.print();
		
	}
//	
	void sagar() {
		System.out.println("\n\nThis is Sagar Method abstrct in Abstract_Superclass");
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
		
		
	}
	
	
}
