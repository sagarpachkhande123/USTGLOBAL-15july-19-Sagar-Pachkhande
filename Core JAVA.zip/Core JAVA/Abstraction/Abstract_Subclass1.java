package com.dev.Abstraction;



abstract class Abstract_Superclass {
	
//	public Abstract_Superclass(){  //can create a constructor of abstract class
//		System.out.println("Constructor of Abstract_SuperClass");
//	}
	
	
	abstract void display();
	abstract void sagar();
	
	public abstract void print();
	
	public void show() {
		System.out.println("\n\nThis is show method of Abstract_SuperClass");
	}
	
}

public abstract class Abstract_Subclass1 extends Abstract_Superclass {

	
	
//	public Abstract_Subclass1() {
//		// TODO Auto-generated constructor stub
//		System.out.println("\n\nConstructor of Abstract_Subclass");
//		
//	}
	
	@Override
	void display() {
		System.out.println("\n\nAbstract Display Method implemented here...");
		System.out.println("This is display method of Abstract_SubClass");
			
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		Abstract_Subclass1 aSub=new Abstract_Subclass1();
//		aSub.show();
//		aSub.display();
	}

}
