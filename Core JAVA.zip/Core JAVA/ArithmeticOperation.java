class ArithmeticOperation{
	public static void main(String[] args) {
		int a=10,b=20,c;

		c=a+b;

		System.out.println("Addition is "+c);
		c=a-b;   //reinitialization
		System.out.println("Substraction is "+c);
		c=a/b;	//reinitialization
		System.out.println("Division is "+c);
		c=a*b;	//reinitialization
		System.out.println("Multiplication is "+c);
		c=a%b;	//reinitialization
		System.out.println("Modulus is "+c);

	}
}