package com.dev.Interface_;

public class Main {
	
	public static void main(String[] args) {
		
	}
}
