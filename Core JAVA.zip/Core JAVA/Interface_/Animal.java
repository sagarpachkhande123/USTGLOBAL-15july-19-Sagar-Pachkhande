package com.dev.Interface_;

public interface Animal {
	public void eat();
	public void sleep();
}
