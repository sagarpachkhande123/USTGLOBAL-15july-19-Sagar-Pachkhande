package com.dev.collections;

public interface Employee_operation {
	public boolean addEmployee(Employee e);
	public boolean removeEmployee(Employee e) ;
	
	public Object retriveEmployee();	
}
