package com.dev.collections;

import java.util.ArrayList;
import java.util.Iterator;


public class Array_List{

	public static void main(String[] args) {
		ArrayList<Employee> al=new ArrayList<>();

		System.out.println("********************");



		Employee e1=new Employee();
		e1.setId(1);
		e1.setEmail("Sagar@gamil.com");
		e1.setName("Sagar");
		e1.setPassword("******");


		Employee e2=new Employee();
		e2.setId(2);
		e2.setEmail("Sagar@gamil.com");
		e2.setName("Sagar");
		e2.setPassword("******");


		Employee e3=new Employee();
		e3.setId(3);
		e3.setEmail("Sagar@gamil.com");
		e3.setName("Sagar");
		e3.setPassword("******");


		al.add(e1);
		al.add(e2);
		al.add(e3);


		System.out.println("Elements in al ArrayList\n"+al);

		System.out.println("********************");

		Iterator i1=al.iterator();
		System.out.println("\n"+(i1.hasNext())+"\n");
		System.out.println("********************");
		while(i1.hasNext())
		{
			System.out.println(i1.next());
		}

		System.out.println("********************");


	}
}
