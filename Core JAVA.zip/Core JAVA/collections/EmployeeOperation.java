package com.dev.collections;

import java.util.HashMap;
import java.util.Iterator;

public class EmployeeOperation implements Employee_operation  {

	HashMap<String, Employee> hm=new HashMap<>();
	
//	EmployeeOperation() {
//
//
//
//		e1.setId(1);
//		e1.setEmail("Sagar@gamil.com");
//		e1.setName("Sagar");
//		e1.setPassword("******");
//
//
//
//		e2.setId(2);
//		e2.setEmail("Sagar@gamil.com");
//		e2.setName("Sagar");
//		e2.setPassword("******");
//
//
//
//		e3.setId(3);
//		e3.setEmail("Sagar@gamil.com");
//		e3.setName("Sagar");
//		e3.setPassword("******");
//
//
//
//
//
//
//	}


	@Override
	public boolean addEmployee(Employee e) {

		hm.put("1", e);
		
		return true;
	}

	@Override
	public boolean removeEmployee(Employee e) {
		
		hm.clear();
		
		return true;
	}

	
	
	
	
	
	
	
	
	@Override
	public Object retriveEmployee() {

		System.out.println(hm);
		return hm;


		
	}

	


}
