package com.dev.collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class Treeset {

	public static void main(String[] args) {


		TreeSet<Integer> ts=new TreeSet<>();

		ts.add(1);
		ts.add(4);
		ts.add(3);
		ts.add(4);

		System.out.println("Elements in TreeSet "+ts);

		System.out.println(ts.ceiling(5));;

		System.out.println("Descending Iterator ");
		Iterator i=ts.descendingIterator();

		while(i.hasNext()) {
			System.out.print(i.next());
		}
		System.out.println();



		System.out.println("********************");

		TreeSet<Employee> ts1=new TreeSet<>();


		Employee e1=new Employee();
		e1.setId(1);
		e1.setEmail("Sagar@gamil.com");
		e1.setName("Sagar");
		e1.setPassword("******");


		Employee e2=new Employee();
		e2.setId(2);
		e2.setEmail("Sagar@gamil.com");
		e2.setName("Sagar");
		e2.setPassword("******");


		Employee e3=new Employee();
		e3.setId(3);
		e3.setEmail("Sagar@gamil.com");
		e3.setName("Sagar");
		e3.setPassword("******");


		ts1.add(e1);
		ts1.add(e2);
		ts1.add(e3);


		System.out.println("Elements in ts1 TreeSet\n"+ts1);

		Iterator i1=ts1.iterator();
		System.out.println((i1.hasNext()));
		while(i1.hasNext())
		{
			System.out.println(i1.next());
		}



		HashSet<Integer> hs=new HashSet<>();

		hs.add(5);
		hs.add(6);

		ts.addAll(hs);

		System.out.println("\n\n\nHashSet Elements Added into the TreeSet Elements \n"+ts);

		System.out.println("All the Elements of Treeset are same with Hashset or not\n  "+ts.containsAll(hs));;






	}

}
