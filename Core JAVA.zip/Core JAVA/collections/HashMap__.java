package com.dev.collections;

import java.util.HashMap;
import java.util.Iterator;

public class HashMap__ extends EmployeeOperation {

	public static void main(String[] args) {
		
		EmployeeOperation eo=new EmployeeOperation();
		
		
		Employee e1=new Employee();
		e1.setId(1);
		e1.setEmail("Sagar@gamil.com");
		e1.setName("Sagar");
		e1.setPassword("******");
	
		System.out.println(eo.addEmployee(e1));;
		eo.retriveEmployee();
		
		
		
		Employee e2=new Employee();
		e2.setId(2);
		e2.setEmail("Sagar@gamil.com");
		e2.setName("Sagar");
		e2.setPassword("******");
		
		System.out.println(eo.addEmployee(e2));;
		eo.retriveEmployee();
		
		
		
		
		System.out.println(eo.removeEmployee(e1));;
		
		if(eo.removeEmployee(e1))
		{
			System.out.println("Hashset is Empty Now");
		}
		
		
//		eo.retriveEmployee();
		
//		HashMap<String, Employee> hm=new HashMap<>();
//		
//		
//
//		Employee e1=new Employee();
//		e1.setId(1);
//		e1.setEmail("Sagar@gamil.com");
//		e1.setName("Sagar");
//		e1.setPassword("******");
//
//
//		Employee e2=new Employee();
//		e2.setId(2);
//		e2.setEmail("Sagar@gamil.com");
//		e2.setName("Sagar");
//		e2.setPassword("******");
//
//
//		Employee e3=new Employee();
//		e3.setId(3);
//		e3.setEmail("Sagar@gamil.com");
//		e3.setName("Sagar");
//		e3.setPassword("******");
//
//		hm.put("1", e1);
//		hm.put("2", e2);
//		hm.put("3", e3);
//		
//		Iterator i=hm.entrySet().iterator();

//		System.out.println("HashMap Elements are ");
//		while(i.hasNext())
//		{
//			System.out.println(i.next());
//		}
//		return hm;
//		
//		
//		
//		System.out.println("\nPut Return the Object \n"+hm.put("1", e1)); //Returns the Object or Value
//		
//		System.out.println("Keys are::");
//		for(String key : hm.keySet())
//		{
//			System.out.println(key);
//		}
//		System.out.println("Values are::");
//		for(Employee value : hm.values())
//		{
//			System.out.println(value);
//		}
//		
////		Employee e=hm.remove("2");
////		System.out.println(e);
//		
//		System.out.println("Output of ContainsKey is ::"
//					+hm.containsKey("6"));
//		
//		System.out.println("Output of ContainsValues is ::"
//				+hm.containsValue(e3));
//		
//		System.out.println("Size of the HashMap is ::"
//				+hm.size());
		
		
	}
}
