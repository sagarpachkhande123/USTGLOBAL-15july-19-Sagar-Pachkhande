package com.dev.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Queue;
import java.util.Set;

import javax.management.Query;

import com.dev.encapsulation.Cat;
import com.dev.encapsulation.DogData;



public class Collections_ {

	public static void main(String[] args) {
		//		 ArrayList<String,String> al=new ArrayList();

		//Declaration
		ArrayList<String> ar=new ArrayList<String>();

		//Adding Elements
		ar.add("1");
		ar.add("2");
		ar.add("3");
		ar.add("4");


		ar.add(1, "1");// append the element at given position
		ar.add(2, "2");

		System.out.println("Before Modification");
		Iterator i=ar.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());

		}

		System.out.println("******");
		ar.set(1, "djshjd"); //replace the element with the original element
		System.out.println("After Modification");
		Iterator i2=ar.iterator();
		//TO get the data from Collection
		while(i2.hasNext())
		{
			System.out.println(i2.next());
		}

		System.out.println("******");


		HashSet<Integer> hs=new HashSet<Integer>();

		hs.add(1);
		hs.add(2);

		Iterator i1=hs.iterator();
		System.out.println("HashSet Elements ");
		while(i1.hasNext())
		{
			System.out.println(i1.next());
		}

		System.out.println("isEmpty Method::"+hs.isEmpty());

		System.out.println("Size of hashSet is "+hs.size());
		System.out.println("HashSet Contans 2 or not::"+hs.contains(2));
		//		 System.out.println("notify() method "+hs.notify(););
		System.out.println(hs.getClass());
		System.out.println("******");
		while(i1.hasNext())
		{
			System.out.println(i1.next());

		}

		HashSet<Cat> hs2=new HashSet<Cat>();

		Cat c1=new Cat();
		c1.setAge(12);
		c1.setColor("Red");
		c1.setName("Abc");

		Cat c2=new Cat();
		c2.setAge(12);
		c2.setColor("Red");
		c2.setName("Abc");

		Cat c3=new Cat();
		c3.setAge(12);
		c3.setColor("Red");
		c3.setName("Abc");


		System.out.println(hs2.add(c1));
		System.out.println(hs2.add(c2));

		System.out.println("Cat Class Variables are inserted into the Collection ");
		System.out.println(hs2);


		System.out.println("\n********************************\n");

		HashSet<Employee> hs3=new HashSet<>();

		Employee e1=new Employee();
		e1.setId(1);
		e1.setEmail("Sagar@gamil.com");
		e1.setName("Sagar");
		e1.setPassword("******");


		Employee e2=new Employee();
		e2.setId(1);
		e2.setEmail("Sagar@gamil.com");
		e2.setName("Sagar");
		e2.setPassword("******");


		Employee e3=new Employee();
		e3.setId(1);
		e3.setEmail("Sagar@gamil.com");
		e3.setName("Sagar");
		e3.setPassword("******");

		hs3.add(e1);
		hs3.add(e2);
		hs3.add(e3);


		System.out.println("Employee Class Variables are inserted into the Collection ");
		System.out.println(hs3);

		System.out.println("Size of hs3 is "+hs3.size());
		System.out.println("e1 Contains or not "+hs3.contains(e1));
		if(hs3.contains(e1)==true){
			System.out.println(e1.getName().equals("Sagar"));
		}
		System.out.println(hs3.contains(e1.getName().equals("Sagar")));

		System.out.println("e1 Contains or not "+hs3.contains(""));

		Iterator i7=hs3.iterator();
		while(i7.hasNext())
		{
			System.out.println(i7.next());
		}

		System.out.println("\n\n********HASHMAP**********");



		


	}
}