class RelationalOperator{
	public static void main(String[] args) {
		int i=10,j=9;
		boolean b= i==j;
		System.out.println(b);

		b=i!=j;
		System.out.println(b);

		b= i|j;
				System.out.println(b);
		b= i&j;
				System.out.println(b);


		int h= i&j;
		System.out.println(h);	
		byte b1=2;
		byte b2=3;
		int r=b1&b2;
		
	}
}