package Method_Overloading;

public class Method_Overloading {
	
	static Method_Overloading mo=new Method_Overloading();
	
	
	public void print() {
		System.out.println("This is print Method with no arguments");
	}
	
	public final void print(int i) {
		
		System.out.println("This is print Method with one integer arguments arguments");
		
	}
	static String print(String str) {
		
		System.out.println("This is print Method with one String arguments arguments");
		return str;
	}
	
	
	public static void main(String[] args) {
		mo.print();
		mo.print(8);
		mo.print("s");
	}

}
