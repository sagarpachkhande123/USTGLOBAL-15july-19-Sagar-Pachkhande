package Method_Overloading;

import java.util.Scanner;

public class Arithmetic_Operation {


	static Arithmetic_Operation ao=new Arithmetic_Operation();

	//	int ArithmeticOperation() {
	//		int i=9,j=8;
	//		int sum=i+j;
	//		
	//		
	//		
	//		return sum;
	//		
	//	}
	//	int ArithmeticOperation(int i,int j)
	//	{
	//		int div=i*j;
	//		return div;
	//		
	//	}
	//	int ArithmeticOperation(short i,int j)
	//	{
	//		int div=i*j;
	//		return div;
	//		
	//	}

	//	**Overloading with add() Method
	int add(int i,int j)
	{

		return i+j;
	}
	int add(int i,int j,int k)
	{
		return i+j+k;
	}
	int add(int i,int j,int k,int l)
	{
		return i+j+k+l;
	}

	//**	Overloading with Sub() Method

	int sub(int i,int j)
	{

		return i-j;
	}
	int sub(int i,int j,int k)
	{
		return (i-j)-k;
	}
	int sub(int i,int j,int k,int l)
	{
		return (i-j)-(k-l);
	}


	//**	Overloading with div() Method

	int div(int i,int j)
	{

		return i/j;
	}
	int div(int i,int j,int k)
	{
		return (i/j)/k;
	}
	int div(int i,int j,int k,int l)
	{
		return (i/j)/(k/l);
	}


	//**Overloading with div() Method

	int mul(int i,int j)
	{

		return i*j;
	}
	int mul(int i,int j,int k)
	{
		return (i*j)*k;
	}
	int mul(int i,int j,int k,int l)
	{
		return (i*j)*(k*l);
	}





	public static void main(String[] args) {

		int ch=0;
		Scanner sc=new Scanner(System.in);
		while(ch<6)
		{
			g:
		System.out.println("Enter Your Choice\n1.Addition\n2.Substraction\n3.Multiplication\n4.Division");
		 ch=sc.nextInt();
		

			switch(ch) {
			case 1:
				System.out.println("****************************************");
				System.out.println("Addition with two arguments "+ao.add(3, 6));
				System.out.println("Addition with three arguments "+ao.add(9, 6,4));
				System.out.println("Addition with four arguments "+ao.add(3, 6,2,4));
				System.out.println("****************************************");
				
				
				
				break;
			case 2:
				System.out.println("****************************************");
				System.out.println("Substraction with two arguments "+ao.sub(3, 6));
				System.out.println("Substraction with three arguments "+ao.sub(9, 6,4));
				System.out.println("Substraction with four arguments "+ao.sub(3, 6,2,4));
				System.out.println("****************************************");
				break;
			case 3:
				System.out.println("****************************************");
				System.out.println("Multiplication with two arguments "+ao.mul(3, 6));
				System.out.println("Multiplication with three arguments "+ao.mul(9, 6,4));
				System.out.println("Multiplication with four arguments "+ao.mul(3, 6,2,4));
				System.out.println("****************************************");
				break;
			case 4:
				System.out.println("****************************************");
				System.out.println("Division with two arguments "+ao.div(14, 6));
				System.out.println("Division with three arguments "+ao.div(67, 6,4));
				System.out.println("Division with four arguments "+ao.div(39, 62,4,2));
				System.out.println("****************************************");
				break;
			default:
				System.out.println("Invalid Choice");
//				int i=8;
//				for(i=1;i<6;)
//				{
//					System.out.println(i);
//					i++;
//					
//				}
				
			}
		}

	}

}
