package com.dev.Method_Overriding;

public class Superclass {
//	Superclass Sc=new Superclass();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		sc.show();
	}
	public void show() {
	System.out.println("Show Method in SuperClass");
	}
	
	public static void static_method()
	{
		System.out.println("static_method in SuperClass");
	}
	
	
	public int add(int i,int j)
	{
		return i*j;
		
	}
}
