package com.dev.Method_Overriding;



//private Method cannot be overriden
//final Method cannot be overriden
// static Method cannot be ovveriden but can be inherited
//if we declare the static method in both parent and child class then they both are not same  


public  class SubClass extends Superclass {
	static SubClass sb=new SubClass();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		sb.show();
		sb.static_method();
		int result=sb.add(8,9);
	}
	@Override
	public void show() {
		super.show();
		System.out.println("Show Method in SubClass");
	}
	
	@Override
	public int add(int i,int j)
	{
		int result=i*j;
		return result;
		
	}
	
	//
	public static void static_method()
	{
		System.out.println("static_method in SubClass");
	}

}
