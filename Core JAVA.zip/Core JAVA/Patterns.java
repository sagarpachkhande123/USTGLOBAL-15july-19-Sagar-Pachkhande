class Patterns{
	public static void main(String[] args) {
		int n=5;
		System.out.println();
		System.out.println();
		System.out.println();
		
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print("*");
			}
			System.out.println();

		}
		
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<5-i;j++)
			{
				System.out.print("*");
			}
			System.out.println();

		}

		
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print("*");
			}
			System.out.println();

		}
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<5-i;j++)
			{
				System.out.print("*");
			}
			System.out.println();

		}
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print("*");
			}
			System.out.println();

		}
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<5-i;j++)
			{
				System.out.print("*");
			}
			System.out.println();

		}
		System.out.println();
		System.out.println();
		System.out.println();


			// Aa
			// Bb Cc
			// Dd Ee Ff
			// Gg Hh Ii Jj
			// Kk Ll Mm Nn Oo

		int f=0;
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print((char)(65+f));
				System.out.print((char)(97+f)+" ");
				f++;

			}
			System.out.println();

		}
		int k=1,m=1;
		// for(int i=1;i<5;i++)
		// {
		// 	for(int j=1;j<=i;j++)
		// 	{
		// 		System.out.println(k);
		// 		k=k+3;
		// 		if(i!=1){
		// 			System.out.println(k);

		// 		}
				
		// 	}
		// 	k=k-2*m;
		// 	m=m+1;
		// 	System.out.println();
			// }
		System.out.println();
		System.out.println();
		System.out.println();



			// 1
			// 25
			// 367
			// 48910



		int p=0;
		for(int i=1;i<5;i++)
		{
			for(int j=1;j<=i;j++)
			{
				if(j==1)
				{
					System.out.print(i*j);

				}
				else
				{
					System.out.print((5+p));
					 p=p+1;
				}
				
			}

			System.out.println();
			 // p=p+2;
		}


		

		System.out.println();
		System.out.println();
		System.out.println();
		


			//   *
			//  ***
			// *****
			//  ***
			//   *


		for(int i=1;i<=3;i++)
		{
			for(int j=1;j<=5;j++)
			{
				if(j>=4-i && j<=2+i)
				{
					System.out.print("*");
				}
				else
					System.out.print(" ");
			}
			System.out.println();			
		}
		for(int i=1;i<=3;i++)
		{
			for(int j=1;j<=5;j++)
			{

				if(j>=i+1 && j<=5-i)
				{
					System.out.print("*");
				}
				else
					System.out.print(" ");
			}
			System.out.println();			
		}

		System.out.println();
		System.out.println();
		System.out.println();



			//   A
			//  BCD
			// EFGHI
			//  123
			//   4

		int q=0;
		for(int i=1;i<=3;i++)
		{
			for(int j=1;j<=5;j++)
			{
				if(j>=4-i && j<=2+i)
				{
					System.out.print((char)(65+q));

					q=q+1;
				}
				else
					System.out.print(" ");
			}
			System.out.println();			
		}
		q=1;
		for(int i=1;i<=3;i++)
		{
			for(int j=1;j<=5;j++)
			{

				if(j>=i+1 && j<=5-i)
				{
					System.out.print(q);
					q=q+1;
				}
				else
					System.out.print(" ");
			}
			System.out.println();			
		}


			System.out.println();
			System.out.println();
			System.out.println();



			
				// ***
				//  *
				// ***
				//  *
				// ***

		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=3;j++)
			{
				if(i%2!=0)
				{
					System.out.print("*");
				}
				else if(i%2==0)
				{
					if(j%2==0)
					{
						System.out.print("*");
					}
					else{
						System.out.print(" ");
					}
					
				}


			}
			System.out.println();
		}

		

		


	}
}