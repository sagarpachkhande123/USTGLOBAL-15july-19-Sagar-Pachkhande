package com.dev.collection1;

public interface Employee_Interface {
	public boolean insertData();
	
	public boolean searchEmp(int empid);
	
	public boolean updateData(int empid);
	
	public boolean removeData(int empid);
	
	public void calTotaltax();
	
	public void netPay();
	
	public void retrieveGrade();
	
	public void retriveData();
	
	
	
	
}
