package com.dev.collection1;

import java.util.HashMap;
import java.util.Scanner;

public class Employee_Operation implements Employee_Interface{

	HashMap<Integer, Employee> hm=new HashMap<>();
	
	
	static int count,i;
	static Employee e1=new Employee();

	Scanner sc=new Scanner(System.in);
	double tax;
	char grade;

	@Override
	public boolean insertData() {
		
		
//		System.out.println("Enter How Many Employees you Want to add in Database");
//		count=sc.nextInt();

//		for(i=1;i<=Main.count;i++) {
//
//			System.out.println("***Enter Employee Deatils "+i+" Employee");
//
//
//			System.out.println("Enter Employee Name");
//			String name=sc.next();
//
//			System.out.println("Enter Employee Email ID");
//			String email=sc.next();
//
//			
//			System.out.println("Enter Employee Salary");
//			double salary=sc.nextDouble();
//

			
//			
			
			hm.put(i, e1);
		
		
			System.out.println(hm);
		
		
		

//		int j=i+1;
		
			
			return true;
		}
			
			
		


	

	@Override
	public boolean searchEmp(int empid) {

		if(hm.containsKey(empid))
		{
			System.out.println(hm);
		}
		if(empid==0)
		{
			System.out.println("Data Not Present");
			return false;
		}
		return true;
	}

	@Override
	public boolean updateData(int empid) {

		if(hm.containsKey(empid))
		{
			System.out.println("Enter Email to Update of Employee having Employee Id "+empid);
			String s=sc.next();
			e1.setEmail(s);
		}

		return true;
	}

	@Override
	public boolean removeData(int empid) {
		if(hm.containsKey(empid))
		{

			System.out.println("Successfully Removed "+hm.remove(empid));

		}
		return true;
	}

	@Override
	public void calTotaltax() 
	{

		if(e1.getSalary()>=1100000)
		{
			tax=1100000*9.35/100;
		}
		//		else if(e1.getSalary()>=860000 && e1.getSalary()<=1000000)
		//		{
		//			tax=1100000*8.87/100;
		//		}
		//		else if(e1.getSalary()>=540000 && e1.getSalary()<=860000)
		//		{
		//			tax=1100000*8.87/100;
		//		}
		//		else if(e1.getSalary()>=380000 && e1.getSalary()<=540000)
		//		{
		//			tax=1100000*8.87/100;
		//		}
		//		else if(e1.getSalary()>=160000 && e1.getSalary()<=380000)
		//		{
		//			tax=1100000*8.87/100;
		//		}
		//		double totalTax=1100000-intce;
		System.out.println("Total tax is "+tax);
	}

	@Override
	public void netPay() {

	}

	@Override
	public void retrieveGrade() {

		if(e1.getSalary()>=1000000)
		{
			grade='A';
		}
		else if(e1.getSalary()>=860000 && e1.getSalary()<=1000000)
		{
			grade='B';
		}
		else if(e1.getSalary()>=540000 && e1.getSalary()<=860000)
		{
			grade='C';
		}
		else if(e1.getSalary()>=380000 && e1.getSalary()<=540000)
		{
			grade='D';
		}
		else if(e1.getSalary()>=160000 && e1.getSalary()<=380000)
		{
			grade='E';
		}
		System.out.println("SalGrade is "+grade);

	}

	@Override
	public void retriveData() {
		System.out.println(hm);

	}


}
