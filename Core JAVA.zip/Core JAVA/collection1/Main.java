package com.dev.collection1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	static Employee_Operation eo=new Employee_Operation();

	static int count,i;
	static Integer k=1;


	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int eid;
		//		ArrayList<Employee> al=new ArrayList<Employee>();

		
		Employee [] e;
		int n=0;

		System.out.println("***Welcome to Employee Management System****");


		while(n<=8)
		{

			System.out.println("\n\n**Enter your choice**\n\n1.Insert Employee Data\n2.Search Employee Data based on Eid\n3.Remove Employee Data \n4.Update Employee Email based on Eid\n5.Calculate Total Tax\n6.Calculate NetPay of Employee\n7.Retrive Grade of an Employee\n8.Retrive Data");
			System.out.println("****************");
			n=sc.nextInt();


			switch(n)
			{
			case 1:
				//			System.out.println("Enter key to Insert Data into Database");
				//			int key

				System.out.println("Enter How Many Employees you Want to add in Database");
				count=sc.nextInt();
				e=new Employee[count];
				for(i=1;i<=count;i++) {

					System.out.println("***Enter Employee Deatils "+i+" Employee");


					System.out.println("Enter Employee Name");
					String name=sc.next();

					System.out.println("Enter Employee Email ID");
					String email=sc.next();

					System.out.println("Enter Employee Password");
					String password=sc.next();


					System.out.println("Enter Employee Salary");
					double salary=sc.nextDouble();


					

					e[i]=new Employee(i,name,email,password,salary);
					
					e[i].setEmpid(i);
					e[i].setName(name);
					e[i].setEmail(email);
					e[i].setSalary(salary);

					if(eo.insertData())
					{
						System.out.println("Employee Successfully Added");
						k++;
						//						System.out.println(k);
					}

				}




				break;

			case 2:
				System.out.println("Enter Employee id to Search");
				eid=sc.nextInt();
				eo.searchEmp(eid);
				break;

			case 3:
				System.out.println("Enter Employee id to Remove From Employee Database");
				eid=sc.nextInt();
				eo.removeData(eid);
				break;

			case 4:
				System.out.println("Enter Employee id to Update data of Employee");
				eid=sc.nextInt();
				eo.updateData(eid);
				break;

			case 5:
				eo.calTotaltax();
				break;

			case 6:
				eo.netPay();
				break;

			case 7:
				eo.retrieveGrade();
				break;

			case 8:
				eo.retriveData();



			}
		}


	}
}

