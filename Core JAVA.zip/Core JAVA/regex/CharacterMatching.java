package com.dev.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CharacterMatching {

	public static void main(String[] args) {

		Pattern p = Pattern.compile("\\w+\\@\\w+\\.\\w{3}");
		Matcher match = p.matcher("sagarpachkahnde@gmail.com");

		System.out.println(" FOr \\d : " + match.matches());

		Pattern p2 = Pattern.compile("\\w+\\d{2,4}\\@\\w+\\.\\w+");
		Matcher match2 = p2.matcher("sagarpachkahnde123@gmail.com");

		System.out.println(" FOr \\d : " + match2.matches());

		Pattern p3 = Pattern.compile("^[a-zA-Z][0-9]\\@\\w+\\.\\w+");
		Matcher match3 = p3.matcher("sagarpachkahnde@gmail.com");

		System.out.println(" FOr \\d : " + match3.matches());

		Pattern p4 = Pattern.compile("\\d{1,2}\\W\\w+\\W\\d{2,4}");
		Matcher match4 = p4.matcher("23-Mon-1997");

		System.out.println(" FOr \\d : " + match4.matches());

		Pattern p5 = Pattern.compile("[1-9]|1[0-9]|2[0-9]");// Takes the input number from 1 to 29
		Matcher match5 = p5.matcher("8");

		System.out.println(" FOr \\d : " + match5.matches());

		Pattern p6 = Pattern.compile("[A-Za-z]{1,25}\\s[A-Za-z]{1,25}");// Takes the input number from 1 to 29
		Matcher match6 = p6.matcher("Sagar Pachkhande");

		System.out.println(" FOr \\d : " + match6.matches());

		Pattern p7 = Pattern.compile("\\w+\\W+\\w+");// Takes the input number from 1 to 29
		Matcher match7 = p7.matcher("jdasb#4dfs");

		System.out.println(" FOr \\d : " + match7.matches());
	
	
	
		Pattern p8 = Pattern.compile("[A-Z{1}][a-z]{1,15}\\s[A-Z{1}][a-z]{1,15}");// Takes the input number from 1 to 29
		Matcher match8 = p8.matcher("Sagar Pachkhande");

		System.out.println(" FOr \\d : " + match8.matches());
	
	}
}
