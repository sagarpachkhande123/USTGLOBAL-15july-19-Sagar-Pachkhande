package com.dev.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternProgram {
	public static void main(String[] args) {
		Pattern p=Pattern.compile("\\d");
		Matcher match=p.matcher("1");
		
		System.out.println(" FOr \\d : "+match.matches());
		
		
		Pattern p2=Pattern.compile("\\d{2,4}");//only two digit matches
		Matcher match2=p2.matcher("188");
		
		System.out.println(" FOr \\d+ : "+match2.matches());
		
		
		Pattern p3=Pattern.compile("\\D{2}");
		Matcher match3=p3.matcher("68");
		
		System.out.println(" FOr \\D : "+match3.matches());
		
		Pattern p4=Pattern.compile("\\s");
		Matcher match4=p4.matcher(" ");
		
		System.out.println(" FOr \\s : "+match4.matches());
		
		Pattern p5=Pattern.compile("\\s+");
		Matcher match5=p5.matcher("     ");
		
		System.out.println(" FOr \\s+ : "+match5.matches());
		
		Pattern p6=Pattern.compile("\\w"); //Represent Character
		Matcher match6=p6.matcher("ff");
		
		System.out.println(" FOr \\s+ : "+match6.matches());
		
		
		
	}
}
