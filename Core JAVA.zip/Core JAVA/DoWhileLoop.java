import java.util.*;
class DoWhileLoop{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
			int i=1;
		System.out.println("Enter Number");
		int n=sc.nextInt();
		System.out.println("Table of "+n+" is");
		do{

			System.out.println(i+".  "+i*n);
			i++;
		}while(i<=10);
	}

}