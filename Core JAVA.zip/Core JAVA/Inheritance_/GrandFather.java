package Inheritance_;

public class GrandFather {

}
