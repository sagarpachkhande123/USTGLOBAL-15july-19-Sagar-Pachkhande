package com.dev.package__;

public class DogData {

	
	public static void main(String[] args) {
		Dog d1=new Dog();
		d1.setAge(3);
		d1.setBreed("Dober Man");
		d1.setColor("Black");
		d1.setName("Shiro");
		
		
		Dog d2=new Dog();
		d2.setAge(3);
		d2.setBreed("Dober Man");
		d2.setColor("Black");
		d2.setName("Shiro");
		
		Dog d3=new Dog();
		d3.setAge(3);
		d3.setBreed("Dober Man");
		d3.setColor("Black");
		d3.setName("Shiro");
		
		System.out.println(d2.equals(d3));
		System.out.println(d3.hashCode());
		
		
		
		
//		c1.setAge(3);
//		c1.setColor("Black");
//		c1.setName("Shiro");
		
		
		
		
		
		
		
		Dog [] dogs= {d1,d2,d3};
		
		
		for(int i=0;i<dogs.length;i++) {
			
//			System.out.println("Name: "+dogs[i].getName());
//			
//			System.out.println("Age: "+dogs[i].getAge());
//			
//			System.out.println("Breed: "+dogs[i].getBreed());
//			
//			System.out.println("Color: "+dogs[i].getColor());
//			
			System.out.println(dogs[i]);
			System.out.println("***************************");
		}
		
		
		
	}
	
}
