package com.dev.package__;

public class Package_Methods implements Cloneable {
	static Dog d1=new Dog();
	static Dog d2=new Dog();
	@Override
	 public Object clone() throws CloneNotSupportedException {
	 return super.clone();
	 }

	public static void main(String[] args) {
		System.out.println(d1.getClass());
		
		System.out.println(d1.equals(d1));
		
	}
	
}
