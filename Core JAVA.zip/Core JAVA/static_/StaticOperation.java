package com.dev.static_;

public class StaticOperation {

}
