package com.dev.sagar;

public class Operation {

	public static int factorial(int n) {
		int result=1;
		for(int i=n;i>=1;i--)
		{
			result=result*i;
		}
		return result;
	}

	public static int swap(int i,int j)
	{
		//int[] ans=new int[2];
		//		
		//		int temp;
		//		temp=i;
		//		i=j;
		//		j=temp;
		//		
		//		ans[0]=i;
		//		ans[1]=j;
		//		
		return i;
	}

	public static long lcm(int n1, int n2) {
		// TODO Auto-generated method stub

		long temp,i=2,res;
		if(n1>n2)
			res=n1;
		else
			res=n2;
		temp=res;
		while(res%n1!=0 || res%n2!=0)
		{
			res=temp*i;
			i++;
		}
		return res;

	}

	public static long gcd(int e, int f) {
		long res=1;

		res=e*f/lcm(e,f);
		return res;
	}

	public static int substract(int g, int h) {	
		return g-h;
	}

	public static int addition(int g, int h) {
		return g+h;
	}

	public boolean palindrom(int n) {
		
		int originalNumber=n;
		int remaider=0,reverseNumber=0;
		while(n!=0) {
			remaider=n%10;
			reverseNumber=reverseNumber*10+remaider;
			n /= 10;
		}
		if(reverseNumber==originalNumber)
		{
			return true;
		}
		else
			return false;
	}

	
	public int numCount(int n) {
		int count=0;
		
		while(n!=0) {
			n=n/10;
			
			count++;
			
		}
		return count;
	}

//	Reverse of the NUmber
	
	public int reverse(int originalNum) {
		int reverseNum=0,remainder=0;
	
		while(originalNum!=0)
		{
			remainder=originalNum%10;
			reverseNum=reverseNum*10+remainder;
			originalNum /= 10;
			
		}
		return reverseNum;
	}
//
//	SUM of Array Elements 
//	@param arr: Input Array
//	
	
	
	public int arrSum(int[] arr) {
		
		int sum=0;
		for(int i=0;i<arr.length;i++)
		{
			sum=sum+arr[i];
		}
		return sum;
	}

	
	public double areaTriangle(int base, int height) {
		// TODO Auto-generated method stub
		
		double res=0.5*base*height;
		return res;
	}
	
	
	public float average(int[] arr) {
		
		float sum=0;
		for(int i=0;i<arr.length;i++)
		{
			sum=sum+arr[i];
		}
		return sum/arr.length;
	}

	public int [] reverseArray(int[] arr) {
		// TODO Auto-generated method stub
		int k=0;
//		System.out.println(arr.length);
		int revArr[]=new int[arr.length];
		for(int i=arr.length-1;i>=0;i--)
		{
			revArr[k]=arr[i];
			k++;
		}
		return revArr;
	}
	

	

}
