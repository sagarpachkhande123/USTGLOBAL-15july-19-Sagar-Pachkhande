class Methods2{
	public static void main(String[] args) {
		double area_circle=Methods1.calArea_Circle(6);
		System.out.println(area_circle);
	}
}