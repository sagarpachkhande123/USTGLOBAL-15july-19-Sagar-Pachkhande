package Inheritance;

public class SuperClass {

	public SuperClass() {
		System.out.println("Constructor with no argument in SuperClass");
	}
	public SuperClass(int i) {
		System.out.println("Constructor with 1 int argument in SuperClass");
	}
	public SuperClass(String s) {
		System.out.println("Constructor with 1 String  argument in SuperClass");
	}
	public SuperClass(int i,String s) {
		System.out.println("Constructor with 1 int and 1 String in SuperClass");
	}
	public SuperClass(String s,int i) {
		System.out.println("Constructor with 1 String and 1 int argument in SuperClass");
	}
	
}
