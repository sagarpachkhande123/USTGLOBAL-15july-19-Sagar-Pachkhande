package Inheritance;
import java.util.*;

public class TwoWheelars {

	static String type_of_car;
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Type of Car");
		type_of_car=sc.next();
		
		
	}

}
