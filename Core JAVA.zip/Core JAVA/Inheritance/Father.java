package Inheritance;

public class Father extends GrandFather {
	
	static Father f=new Father();
	String name="Vitthalrao";
	@Override
	public void printName() {
		//using super keyword
		System.out.println("In printName Method of Father class \n"+name+" "+super.name+" "+f.LastName);
		super.printName();
	}

	public static void main(String[] args) {
		
		f.printName();
		
		
	}

}
