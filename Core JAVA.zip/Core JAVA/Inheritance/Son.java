package Inheritance;

public class Son extends Father {

	static Son s=new Son();
	
	
	public static void main(String[] args) {
		
		s.printName();
		
	}
	
	@Override
	public void printName() {
		 String name="Sagar";
		System.out.println("In printName of Son  class\n"+name+" "+s.name+" "+s.LastName);
		
	}
	
}
