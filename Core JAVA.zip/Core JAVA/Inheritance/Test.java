package Inheritance;

public class Test {
	
	public static void main(String[] args) {
		Test t = new Test();
	}
}
