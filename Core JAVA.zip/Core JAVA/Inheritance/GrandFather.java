package Inheritance;

public class GrandFather {

	static GrandFather g=new GrandFather();
	
	static String LastName="Pachkhande";
	String name="Namdeo";
	public static void main(String[] args) {
		
		g.printName();

	}
	protected void printName() {
		
		System.out.println("In printName class of Grandfather\n"+name+" "+g.LastName);
		
	}

}
