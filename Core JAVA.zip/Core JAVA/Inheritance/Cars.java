package Inheritance;

public class Cars extends TwoWheelars {

	static Cars c=new Cars();
//	static String type_of_car="sagar";
	
	public static void main(String[] args) {
		TwoWheelars.main(args);
		System.out.println("Type of Car is "+c.type_of_car);

	}

}
