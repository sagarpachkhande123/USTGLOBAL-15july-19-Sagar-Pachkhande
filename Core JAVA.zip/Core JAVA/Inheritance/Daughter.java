package Inheritance;

public class Daughter extends Father {
	
	static Daughter d=new Daughter();
	
	
	public static void main(String[] args) {
		
		d.printName();
		
	}
	public void printName() {
		 String name="Priti";
		System.out.println("In printName  of Daughter class\n"+name+" "+d.name+" "+g.LastName);
		
		super.printName();
		
	}
	
	


}
