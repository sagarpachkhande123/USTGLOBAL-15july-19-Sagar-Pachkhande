package Inheritance;

public class SubClass extends SuperClass {
	static SubClass sb=new SubClass();
	public SubClass() {
		
		System.out.println("Constructor with no argument in  Subclass Constructor");
		
	}
	
	public SubClass(int i) {
		super(i);
		System.out.println("Constructor with 1 int argument in  Subclass Constructor");
		
	}
	
	public SubClass(String s) {
		super(s);
		System.out.println("Constructor with 1 string argument in  Subclass Constructor");
		
	}
	public SubClass(String s,int i) {
		super(s,i);
		System.out.println("Constructor with 1 string and 1 int argument in  Subclass Constructor");
		
	}
	public static void main(String[] args) {
		
		
	}

	

}
