import java.util.*;
public class Variables
{
	public static void main(String [] args)
	{
		int i;	//declaration
		i=66;	//initialization
		System.out.println((char)i);	//utilization


		char c;					//declaration
		c=(int)97;
		System.out.println((char)c);


		short s;//declaration
		s=10;
		System.out.println(s);

		long l;//declaration
		l=45;
		System.out.println(l);

		byte b;//declaration
		b=10;
		System.out.println(b);

		double d;//declaration
		d=78899.788;
		System.out.println(d);

		float f;//declaration
		f=56.9f;
		System.out.println(f);

		boolean bo;//declaration
		bo= true && false;
		System.out.println(bo);


		Scanner sc=new Scanner(System.in);

		System.out.println("Enter Size of arrray");
		int size=sc.nextInt();
		int add1=0,add2=0;
		int arr[]=new int[size];
		System.out.println("Enter "+size+" elements");
		for (int h=0;h<size ;h++ ) {
			arr[h]=sc.nextInt();
		}

		for (int o=0;o<size ;o=o+2 ) 
		{
			add1=add1+arr[o];
		}
		for (int j=1;j<=size ;j=j+2 ) 
		{
			add2=add2+arr[j];
			
		}
		System.out.println("Biggest array Addition is");
		if(add2>add1){
			System.out.println(add2);
		}
		else{
			System.out.println(add1);
		}

	}
}