class Increament_Decreament
{
	
	public static void main(String [] args)
	{
		int r=0;
		for(int i=0;i<100;i++)
			r=r++;
		System.out.println("Postincrementor::"+r);

		for(int i=0;i<100;i++)
			r=++r;
		System.out.println("Preincrementor::"+r);
	}
}