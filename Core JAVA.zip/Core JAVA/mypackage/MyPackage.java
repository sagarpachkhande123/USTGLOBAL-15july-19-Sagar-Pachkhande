package com.dev.mypackage;

import java.util.Scanner;
import com.dev.sagar.*;

public class MyPackage  {
	
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Operation op=new Operation();
		
		
//		System.out.println("Enter number for Factorial");
//		
//		int n=sc.nextInt();
//		
//		System.out.println(Operation.factorial(n));
//		
//		int a,b;
//		System.out.println("Enter Two NUmber");
//		a=sc.nextInt();
//		b=sc.nextInt();
//		
//		a=Operation.swap(b, b=a);
		
//		System.out.println("Enter Two NUmber for lcm");
//		int c=sc.nextInt();
//		int d=sc.nextInt();
//		
//		System.out.println("Lcm is "+Operation.lcm(c,d));
//		
//		System.out.println("Enter Two NUmber for gcd");
//		int e=sc.nextInt();
//		int f=sc.nextInt();
//		
//		System.out.println("Lcm is "+Operation.gcd(e,f));
//		
//		System.out.println("Enter Two NUmber for Substraction");
//		int g=sc.nextInt();
//		int h=sc.nextInt();
//		
//		System.out.println("Lcm is "+Operation.substract(g,h));
//		
//		System.out.println("Enter Two NUmber for Addition");
//	
//		
//		System.out.println("Lcm is "+Operation.addition(g,h));
//		
		
//		System.out.println("Enter Number For Palindrom");
//		
//		int i=sc.nextInt();
////		System.out.println("Reverse nuber is+"+op.reverse(i));
//		System.out.println("Palindrom or not:"+op.palindrom(i));
//					
//		System.out.println("Number Count:"+op.numCount(i));
//				
//		System.out.println("Revrese Number is "+op.reverse(i));
		
		
		System.out.println("Enter Array size");
		int j=sc.nextInt();
		int arr[]=new int[j];
		System.out.println("Enter Array Elements");
		for(int k=0;k<j;k++)
		{
			arr[k]=sc.nextInt();
		}
		
//		System.out.println("Average of array is "+op.average(arr));
////		Operation.swap(a, b);
////		System.out.println("a="+a);
////		System.out.println("b="+b);
//		
//		int len=6;
//		int height=7;
//		
//		System.out.println("Area of Traingle is "+op.areaTriangle(len,height));
//		
//		for(int i=arr.length-1;i>=0;i--)
//		{
//		System.out.println("Reverse Array is "+arr[i]);
//		}
		int []revArr=new int[arr.length];
		revArr=	op.reverseArray(arr);
		System.out.println("Reverse Array is");
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(revArr[i]);
		}
	}

}
