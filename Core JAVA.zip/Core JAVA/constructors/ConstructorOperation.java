package com.dev.constructors;

public class ConstructorOperation {

	public ConstructorOperation(int j) {
		System.out.println("Inside Parametarised constructor");
		System.out.println(j);
	}
	public ConstructorOperation() {
		System.out.println("Inside Default constructor");
		
	}
	public ConstructorOperation(String s) {
		System.out.println("Inside String Constructor");
	}
	public ConstructorOperation(int os,String k) {
		System.out.println("Inside String and int Constructor");
	}
	
	
	public static void main(String [] args) {
		//  ConstructorOperation co=new ConstructorOperation();   Show an error bcoz above is parametarised constructor
		ConstructorOperation co=new ConstructorOperation(8+6); //passing 8 since it is parametarised constructor
		ConstructorOperation c=new ConstructorOperation();
		ConstructorOperation ce2=new ConstructorOperation("A");
		ConstructorOperation ce3=new ConstructorOperation(3,"A");
		
		System.out.println("Adress of default Constructor::"+c);
		System.out.println("Adress of String Constructor::"+ce2);
		System.out.println("Adress of string and integer Constructor::"+ce3);
		
		
		
		
		
		
	}
}




