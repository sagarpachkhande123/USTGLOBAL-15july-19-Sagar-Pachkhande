import java.util.*;
class SwitchCase{
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);

		System.out.println("Enter Number to know the respective day");
		int a=sc.nextInt();
		switch(a)
		{
			case 1: 
				System.out.println("Sunday");
				break;
			case 2:
				System.out.println("Monday");
				
				break;
			case 3:
				System.out.println("tueday");
				break;
			case 4: 
				System.out.println("Wednesday");
				break;
			case 5: 
				System.out.println("Thursday");
				break;
			case 6: 
				System.out.println("friday");
				break;
			case 7: 
				System.out.println("Saturday");
				break;
			default:
				System.out.println("Invalid Choice..");
		}
	}
}