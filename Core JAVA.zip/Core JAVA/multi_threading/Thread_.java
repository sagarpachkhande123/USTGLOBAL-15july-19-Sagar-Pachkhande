package com.dev.multi_threading;

public class Thread_ {

	
	
	public static void main(String[] args) {
		Thread t =new Thread();
		System.out.println("Threading...");
		t.start();
		
		t.run();
		
	}
	public void start()
	{
		System.out.println("Thread has Started");
	}
	
}
