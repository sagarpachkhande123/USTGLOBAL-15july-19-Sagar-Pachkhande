package com.dev.multi_threading;

public class Thread2 extends Thread {

	Printer p;
	
	public Thread2(Printer pref) {
		
		p=pref;
	}  
	
	@Override
	public void run() {
		
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {}
		
		p.printVal(10,"Thread 2");
	}
}
