package com.dev.multi_threading;

public class Thread3 extends Thread {

	Printer p;
	
	public Thread3(Printer pref) {
		
		p=pref;
	}  
	
	@Override
	public void run() {
		p.printVal(10,"Thread 3");
	}
}
