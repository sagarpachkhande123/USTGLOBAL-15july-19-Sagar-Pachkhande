package com.dev.multi_threading;

public class Test extends Thread {

	public static void main(String[] args) {
		System.out.println("Main Thread Started");

		//		for(int i=1;i<=100000;i++)
		//		{
		//			System.out.println("i = "+i);
		//		}
		//		
		System.out.println("----------");
		//		for(int j=1;j<=10;j++)
		//		{
		//			System.out.println("j = "+j);
		//		}

		int k=1;

		for(int i=1,j=1;i<6 && j<6;i++,j++)
		{
//			if(k%2!=0)
//			{
//				try {
//					sleep(1000);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//
//				System.out.print("i "+i);
//			}
//			else 
			{
				try {
					sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				System.out.print("i "+i);
			}

			try {
				sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.print("  j "+j);

			System.out.println();
			k++;
		}
		
		


		System.out.println("Main Thread Terminated");
	}


}
