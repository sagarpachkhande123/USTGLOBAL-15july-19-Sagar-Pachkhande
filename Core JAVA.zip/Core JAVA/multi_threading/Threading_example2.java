package com.dev.multi_threading;

public class Threading_example2 extends Thread {

	@Override
	public void run() {
		
				System.out.println("Thread T2 Started..");
		
		for(int j=0;j<10;j++)
		{
			System.out.println("j "+j);			
		}
		
		
		System.out.println("Thread T2 Terminated..");
		
	}
}
