package com.dev.multi_threading;

public class SyncMain {
	public static void main(String[] args) throws InterruptedException {
		System.out.println("SyncMian Thread Started...");
		Printer p=new Printer();
		
		
//		new Thread2(p).start();
		
		Thread2 t2=new Thread2(p);
		t2.start();
		
//		t2.join();// wait the thread to die
		
		new Thread3(p).start();
	
		System.out.println("SyncMian Thread Terminated...");
		
	}
}
