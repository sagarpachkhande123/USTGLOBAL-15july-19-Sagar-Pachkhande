package com.dev.multi_threading;

public class Threading_example extends Thread {

	public static void main(String[] args) {


		System.out.println("Main Method Started..");



		for(int i=0;i<=4;i++)
		{
			System.out.println("i "+i);
		}


		System.out.println();

		Thread.currentThread().setName("Main Thread");
		System.out.println("Get Thread Main Id:: "+Thread.currentThread().getId());


		

		new Threading_example2().start();
		

		Threading_example2 t2=new Threading_example2();
		t2.setName("Thread 2");
		
				
		//		Thread t=new Thread(t2);
		//		t.start();

		System.out.println("Get Thread t2 Name:: "+t2.getName());
		System.out.println("Get Thread t2 Id:: "+t2.getId());
		System.out.println("t2 Thread Stack Trace:: "+t2.getStackTrace().toString());
		
		
		System.out.println("Main Thread Name:: "+Thread.currentThread().getName()+"\n\n");

		
		
		Test t1=new Test();
		System.out.println("t1 Thread Id "+ t1.getId());
		
		System.out.println("Main Thread Terminated..");
		System.out.println();
		System.out.println();
		
		
	}


}
