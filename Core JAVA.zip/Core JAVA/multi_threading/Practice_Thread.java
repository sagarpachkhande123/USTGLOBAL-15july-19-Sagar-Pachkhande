package com.dev.multi_threading;

public class Practice_Thread extends Thread{
	
	public static void main(String[] args) {
		int k=0;
		for(int i=0,j=0;i<5 && j<5;i++,j++)
		{
			
			try {
				sleep(500);
			} catch (InterruptedException e) {}
			
			
			System.out.print("i "+i);
			
			try {
				sleep(500);
			} catch (InterruptedException e) {}
			
			System.out.print("  j "+j);
			
			System.out.println();
				
			
		}
	}
}
