package com.dev.methods;

public class Array_Example {
	
	public static int k=98;	//allowed
	public static int l;
	static Array_Example ae=new Array_Example();
	
	
	public static void main(String[] args) {
		System.out.println();
		
		
		int area=AreaSquare(7);
		
		System.out.println("Area of Square is "+area);
		
	
		
//		Array_Example ae=new Array_Example();
		
		
		int area1=ae.areaRec(9,7);
		System.out.println(("Area of Rectangle is "+area1));
	}
	
	public static int AreaSquare(int j)
	{
//		static int k; Not allowed
		
		int h=ae.areaRec(9,9);
		System.out.println(h);
										//Doublle declaration of one variable is allowed inside method and inside class since one is local and another one is global method
		return (7*7);
	}
	
	

	public int areaRec(int i, int j) {
		
//		static int k; Not allowed
		System.out.println("k is inside areaRec method"+k);
		return (i*j);
		
	}
	
	//cannot access in another package
	private static int sagar() {
		
		System.out.println("Sagar private Method");
		return 9;
	}
	
	
}
