class ForLoop{
	public static void main(String[] args) {
		int[] a={12,9,5,8};
		int[] b={89,67,4};
		int[] t;
		int i=0,j=0;
		if(a.length > b.length)
		{
			 t=new int[a.length];
			 
			 // for(int i=b.length,j=0;i>0,j<b.length;i--,j++)
				// {
				// 	t[i]=a[i];
				// 	a[i]=b[j];
				// 	b[i]=t[i];
				// }
			 for (i=0;i<=a.length;i++) {
			 	for(j=b.length+1;j>=0;j--)
			 	t[i]=a[i];
			 	a[i]=b[j];
			 	b[i]=t[i];
			 	
			 }
		}
		// else
		// {
		// 	t=new int[b.length];
		// 	for(int i=b.length,int j=0;i>0,j<b.length;i--,j++)
		// 		{
		// 			t[i]=a[i];
		// 			a[i]=b[j];
		// 			b[i]=t[i];
		// 		}
		// }

		
		System.out.println("a Array is::");
		for(int p:a){
			System.out.println(a[p]);
		}

		
		System.out.println("b Array is::");
		for(int p:b)
			System.out.println(b[p]);

		}
		
}