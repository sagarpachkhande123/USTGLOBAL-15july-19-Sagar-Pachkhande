import java.util.*;
class If_Else_Marks_system{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Name");
		String nm=sc.next();
		System.out.println("Enter your Marks");
		int marks=sc.nextInt();
		if(marks>100){
			System.out.println(nm+" Beta..hm choo nhi hai.....Acheese Dal MArks");
		}
		else if(marks >= 91 && marks <= 100){
			
			System.out.println(nm+" Beta A Grade mila hai...");
		}
		else if(marks >= 81 && marks <= 90){
			
			System.out.println(nm+" Beta B Grade mila hai...");
		}
		else if(marks >= 71 && marks <= 80){
			
			System.out.println(nm+" Beta C Grade mila hai...");
		}
		else if(marks>=61 && marks <= 70){
			
			System.out.println(nm+" Beta D Grade mila hai...");
		}

		else if(marks>=51 && marks <= 60){
			
			System.out.println(nm+" Beta E Grade mila hai...");
		}
		else if(marks>=41 && marks <= 50){
			
			System.out.println(nm+" Beta F Grade mila hai...");
		}
		else{
			System.out.println(nm+" Beta Fail Hua hai.....Sad mat ho..koi bat nhi Next time Try krna ");
		}
	}
}