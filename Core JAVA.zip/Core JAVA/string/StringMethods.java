package com.dev.string;

public class StringMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Sagar Pachkhande";
		String str1="Sagar";
		
//		Length function
		
		System.out.println("Length function::"+str.length());
		
//		toCharArray() function
		
		char ch[]=str.toCharArray();
				
		System.out.println("Length function::"+ch[str.length()-1]);
		
//		charAt() function
		
		System.out.println("charAt() function::"+str.charAt(6));
		
//		equals() function
		
		System.out.println("equals() function::"+str.equals(str1));
		
//		equalsIgnoreCase()
		
		System.out.println("equalsIgnoreCase()::"+str.equalsIgnoreCase("sagar pachkhande"));
	
//		contains() function
		
		System.out.println("x is present in given string is:: "+str.contains("x"));
		
//		replace() function
		
		System.out.println("Replacing Sagar with Vitthalrao:: "+str.replace("Sagar", "Vitthalrao"));
		
//		indexof() function
		System.out.println("index of g is "+str.indexOf('a'));
		
		System.out.println("index of z is "+str.indexOf('z'));
		
//		lowercase() function
		
		System.out.println("LowerCase of string 1 is:: "+str.toLowerCase());
		
		
		
	}

}
