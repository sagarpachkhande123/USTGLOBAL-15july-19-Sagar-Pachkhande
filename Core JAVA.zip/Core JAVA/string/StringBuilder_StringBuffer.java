package com.dev.string;

public class StringBuilder_StringBuffer {
	public static void main(String[] args) {
		String str= "Sagar";
		
		
//		StringBuffer sbuff1="Sagar"; Not Allowed
		
		StringBuffer sbuff=new StringBuffer("Sagar_with_String_Buffer");
		
		System.out.println(sbuff);
		
		
//		StringBuilder sbuld="Sagar" Not Allowed
		
		StringBuilder sbuild=new StringBuilder("Sagar With StringBuilder");
		
		System.out.println(sbuild);
		
		
		System.out.println("Capacity of sbuff"+sbuff.capacity());
		System.out.println("Length of sbuff"+sbuff.length());
	}

}
