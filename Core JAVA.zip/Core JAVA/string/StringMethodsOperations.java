package com.dev.string;
import java.util.*;

public class StringMethodsOperations {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter String 1::");
		String s1=sc.next();
		
		System.out.println("Enter String 2::");
		String s2=sc.next();
		
		System.out.println("Length of "+s1+" is "+s1.length());
		System.out.println("Length of "+s2+" is "+s2.length());
		
		char a[]=s1.toCharArray();
		char b[]=s2.toCharArray();
		
		System.out.println("Third letter of "+s1+" is "+a[3]);
		System.out.println("Third letter of "+s2+" is "+b[3]);
		
		
		System.out.println("forth letter of "+s1+" is "+s1.charAt(4));
		System.out.println("fourth letter of "+s2+" is "+s2.charAt(4));
		
		if(s1.equals(s2))
		{
			System.out.println("two  string are equals");
		}
		else {
			System.out.println("two  string are not equals");
			
		}
		
		if(s1.equalsIgnoreCase(s2))
		{
			System.out.println("two  string are equals  by ignoring casess");
		}
		else {
			System.out.println("two  string are not equals by ignoring cases also");
			
		}
	}

}
