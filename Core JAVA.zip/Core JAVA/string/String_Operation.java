/**
 * 
 */
package com.dev.string;

/**
 * @author Administrator
 *
 */
public class String_Operation {

	
	public static void main(String[] args) {
		
		String str;
		str="Sagar";
		
		String str1="Pachkhande";
		
		String str2=new String("Xyz");
		
		System.out.println(str);
		System.out.println(str1);
		System.out.println(str2);
		
		
		
		
	}

}
