package com.dev.string;

import java.util.Scanner;

public class ReverseString {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String");
		String str=sc.nextLine();
		
		String res="";
		for(int i=str.length()-1;i>=0;i--)
		{
			res=res+str.charAt(i);
		}
		
		System.out.println("Reverse String is "+res);
		
		int arr[]=new int[7];
		System.out.println("Enter Seven Element in an array");
		for(int i=0;i<7;i++) {
			arr[i]=sc.nextInt();
		}
		
		System.out.println("Sum of first Element and Second Last Element of an Array "+(arr[0]+arr[arr.length-1]+arr[arr.length/2]));
	}
	
	
}
