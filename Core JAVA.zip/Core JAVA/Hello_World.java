import java.io.*;
import java.util.*;

public class Hello_World{

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		System.out.println("Print by Println()");
		// System.out.print("********Hello_World*********");
		System.out.print("\nPrint by print()\n");
		String s=System.out.printf("Print by Printf()\n").toString();
		// int f=Integer.parseInt(s);
		System.out.println(s.length());
		// System.out.println(f);
		System.out.println("\\n");

		//  int 9i, o p,;		 error:-  not a statement  
		int $i,_o; 				//Work Fine

		String p;

		float q=1.335345241234f;
		System.out.println(q);

		double a=1.42343342434346753345676544343;
		System.out.println(a);

		System.out.println("Enter String\n");
		p=sc.nextLine();

		char g[]=p.toCharArray();

		System.out.println("\n\nSkipped Word is");

		for (int i=0;i<p.length();i++ ) {

				g[i]=(char)((int)g[i]+1);
				

				if(g[i]>=97)
				{
					g[i]=(char)((int)g[i]-32);
				}
				else{
					g[i]=(char)((int)g[i]+32);
				}
				System.out.print(g[i]);
	
		}
// int arr[]=new int[4];

		int arr[]=new int[p.length()];
		System.out.print("\nAsscii Number of above Character is\n");

		System.out.print("\n[");
		for (int i=0;i<arr.length ;i++ ) {

			arr[i]=(int)g[i];

			System.out.print(arr[i]+",");
			
		}
		System.out.print("]\n");

		boolean o= true & false;

		System.out.println("Boolean using & operator "+o);

		String res="";

		for (int j=p.length()-1;j<=0 ;j--) {
					res=res+p.charAt(j);

			}
			System.out.println("Reverse String is::"+res);

		// for (int i=0;i<p.length() ;i++ ) {

		// 	// int k=(p.charAt(i)+1);
			
		// 	// if(p.charAt(i)=='a')
		// 	// {
		// 	// 	p.charAt(i)='$';
		// 	// }
		// 	// System.out.print(p.charAt(i));
		// 	if(p.charAt(i)>'97')
			
			
		// }

		//byte j=129;    //range -128 to 127
		//System.out.print(j);
		// short k=32768	;
		// System.out.println(k);




		
		}
}


