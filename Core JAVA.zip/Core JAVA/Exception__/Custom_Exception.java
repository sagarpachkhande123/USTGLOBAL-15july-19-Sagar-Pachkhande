package Exception__;

public class Custom_Exception extends Exception {

		public Custom_Exception() {
			System.out.println("Custom Exception....");
		}

		public Custom_Exception(int i) {
			System.out.println("Custome Exception of int type");
		}

		public Custom_Exception(String string) {
			System.out.println("Custome Exception of string  type");
		}
}
