package Exception__;

public class Exception_Example {

	public static void main(String[] args) {
		double d=10.0;
		double q=0.0;
		System.out.println("Result "+d/q);//Infinity
		
		System.out.println("Before Exception");
		t();
		System.out.println("Before Exception");
		
	}

	private static void t() {
		// TODO Auto-generated method stub
		s();
	}

	private static void s() {
		// TODO Auto-generated method stub
//		StringBuffer sb=new StringBuffer(-1);
		
	}
	
	
}
