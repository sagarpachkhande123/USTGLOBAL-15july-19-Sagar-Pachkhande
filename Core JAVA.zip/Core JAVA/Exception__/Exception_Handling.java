package Exception__;

public class Exception_Handling {

	public static void main(String[] args) {
		try {
			s();
		}
		catch(Exception e) {
			System.out.println(e);
			e.printStackTrace();
			e.getMessage();
		}
		finally {
			System.out.println("This is finally block😊❤");
		}
				System.out.println("Code after Exception");
	}

	private static void s() {
		// TODO Auto-generated method stub
		StringBuffer sb=new StringBuffer(-1);
	}
}
