package Exception__;

public class not_exception {

	public static void main(String[] args) throws Exception {
		try {
			int a=10/0;
		}
		catch(NullPointerException e)
		{
			System.out.println(e);
		}
		catch(Exception e)
		{
			System.out.println("E");
		}
		
	}
}
