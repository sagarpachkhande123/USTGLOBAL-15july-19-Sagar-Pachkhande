package Exception__;

public class ExceptionsHandling2 {
      public static void main(String[] args) throws Custom_Exception 
      {
    	s();
	  }
	private static void s() throws Custom_Exception {
		int i=-1;
		if(i<0)
		{
			throw new Custom_Exception();
		}
	}
}
