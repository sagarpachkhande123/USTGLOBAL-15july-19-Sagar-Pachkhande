package Exception__;

public class Exception_Handling_throws  {

	public static void main(String[] args) throws Custom_Exception 

	{
//		try {
//			s();
//		} catch (Exception e) {
//			throw new Custom_Exception();
//		}
		
		
		try {
			divide(56,0);
		} catch (Exception e) {
			throw new Custom_Exception(1);
		}
	}
	private static int divide(int i, int j) {
		int res=i/j;
		System.out.println(res);
		return 1;
		
	}
	private static void s() throws Custom_Exception
		{
		try {
			StringBuffer sb=new StringBuffer(-1);
			throw new Custom_Exception();
		} catch (Custom_Exception e) {
			System.out.println("Catch Block");
			
		}
	}
}
