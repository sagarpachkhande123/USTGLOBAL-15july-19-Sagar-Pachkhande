package com.dev.lambda_Expression;

public interface FuncInterface_2 {
	public void printval(int a, int b);
}
