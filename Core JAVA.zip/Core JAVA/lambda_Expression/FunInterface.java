package com.dev.lambda_Expression;




public interface FunInterface {
	
	public void printval();

	
}
