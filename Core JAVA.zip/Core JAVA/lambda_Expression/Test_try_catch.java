package com.dev.lambda_Expression;

public class Test_try_catch {
	public static void main(String[] args) {
		FunInterface f=()->{
			try {
				int i=10/9;
				System.out.println("i= "+i);
				
			}
			catch(Exception e){
				System.out.println("Exception Caught "+e);
			}
			finally {
				System.out.println("This is Finally Block");
				
			}
			
			
		};
		
		
		
		FuncInterface_2 f2=(int a, int b)->{
			System.out.println("Addition is "+(a+b));
		};
		f.printval();
		f2.printval(8,9);
	}
	
	

}
