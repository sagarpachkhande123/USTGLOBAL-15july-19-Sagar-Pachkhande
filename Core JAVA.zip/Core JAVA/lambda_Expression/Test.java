package com.dev.lambda_Expression;

public class Test {

	public static void main(String[] args) {
		FunInterface f= () -> {
			for(int i=1;i<=10;i++) {
				System.out.println("i= "+i);
			}
		};
		f.printval();
		
	}
}
