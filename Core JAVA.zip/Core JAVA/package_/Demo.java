package package_;
import com.dev.methods.*; 
import com.dev.encapsulation.*;
public class Demo {
	
	static Demo d=new Demo();
	static int i=11;
	public static void main(String[] args) {
		int q=Array_Example.AreaSquare(6); 
		
		System.out.println("Area of square is imported from different packages "+q);
		System.out.println("i "+d.i);
	
//		int d=Array_Example.sagar();
		
	}
	
		
}
