class Methods{
	public static void main(String[] args) {
		double area_circle=calArea_Circle(6);
		System.out.println(area_circle);
		double avg=calAvg_(6,9,4);
		System.out.println(avg);
		double a_tri=calArea_triangle(8,9);
		System.out.println(a_tri);
	}
	public static double calArea_Circle(int r)
	{
		double circle=3.14*r*r;
		return circle;

	}
	public static double calAvg_(int x, int y, int z)
	{
		int sum=x+y+z;
		return (sum/3); 
	}
	public static double calArea_triangle(int x,int y)
	{
		return (0.5*x*y);

	}
}