package com.dev.arrays;

public class ArraysOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[];
		a=new int[10];
		
		byte byteArr[]=new byte[10];
		
		byteArr[0]=1;
		byteArr[1]=2;
		byteArr[2]=3;
		byteArr[3]=4;
		byteArr[4]=5;
		byteArr[5]=6;
				
		
		System.out.println("\n\nMultiplication::"+byteArr[1]*byteArr[3]);
		System.out.println("\n\nAddition::"+byteArr[1]+byteArr[3]);
		System.out.println("\n\nDivision::"+byteArr[1]/byteArr[3]);
		System.out.println("\n\nModulus::"+byteArr[1]%byteArr[3]);

		int b[]= {1,4,6,9};
		System.out.println("\n\n2nd Element of b array is::"+b[2]);
		System.out.println("Length of an Array Is::"+b.length);
		
		
	
		
		
	}

}
