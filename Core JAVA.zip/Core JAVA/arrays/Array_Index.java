package com.dev.arrays;
import java.util.*;
public class Array_Index {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Index No.");
		int index=sc.nextInt();

		int a[]= {1,2,4,5,7};

		
		
		
		if(a.length>index)
		{
			System.out.println("Index is Present");
			System.out.println("Value at "+index+" is::"+a[index]);
			for(int i=0;i<=index;i++)
			{
				System.out.print(a[i]+",");
			}
		}
		else {
			System.out.println("Index is not Present");
		}
		System.out.println("\n\nMiddle Element is ::"+a[(a.length)/2]);
	}

}
