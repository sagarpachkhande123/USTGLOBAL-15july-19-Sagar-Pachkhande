package com.dev.polymorphism;

public class CompileTimePolymorphism {
	
	static CompileTimePolymorphism cp=new CompileTimePolymorphism();
	public void main(int i) {
		System.out.println("\n\nIn CompileTime Polymorphism::\n Main Method overloaded with *Integer* Argument ");
		
	}
	public static void main(String str) {
		System.out.println("\n\nMain Method overloaded with *String* Argument in CompileTime Polymorphism");
	}
	public static void main(char c) {
			System.out.println("\ns\nMain Method overloaded with *char* Argument in CompileTime Polymorphism");
	}
	
	public static void main(String[] args) {
		
		CompileTimePolymorphism.main('c');
		cp.main(2);
		CompileTimePolymorphism.main("sagar");
		
	}
	
	
	
	

}
