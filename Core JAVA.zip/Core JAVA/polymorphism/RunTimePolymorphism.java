package com.dev.polymorphism;

public class RunTimePolymorphism extends CompileTimePolymorphism {

	static RunTimePolymorphism Rp=new RunTimePolymorphism();
	public void main(int i) {
		super.main(8);
		System.out.println("\n\nIn Runtime Polymorphism::\nMain Method overrriden with *Integer* Argument ");
		
	}
	public static void main(String[] args) {
//		Rp.main(args);
		CompileTimePolymorphism.main(args);
		Rp.main(5);
	}
}
